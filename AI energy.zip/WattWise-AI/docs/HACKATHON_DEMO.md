# Demo flow

1. Open Factory overview.
2. Show energy, cost, CO2 and anomaly cards.
3. Explain Compressor 02: high idle time + high energy + zero output.
4. Open AI Copilot and ask: "Why did energy consumption increase today?"
5. Ask: "How much can we save?"
6. Explain that telemetry is simulated and can later be replaced by MQTT/PLC/sensor streams.

Pitch: WattWise AI turns raw machine telemetry into explainable energy actions. Instead of another dashboard, it tells a plant operator which machine is wasting energy, why the model believes it is happening, and what intervention could reduce cost and carbon.
